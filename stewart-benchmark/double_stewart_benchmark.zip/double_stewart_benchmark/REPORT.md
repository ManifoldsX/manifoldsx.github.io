# ManifoldsX vs MuJoCo: Double Stewart Platform

2026-10-12 · ManifoldsX

## Result

The MuJoCo twin drives its legs with constraints, as ManifoldsX does, and runs with the stiffest constraint settings MuJoCo accepts. At 1 ms steps it holds the top platform to 0.11 mm at 16.6× real time. ManifoldsX at 13–14× real time tracks the exact solution to 0.00002 mm (2e-8 m, the size of its Newton tolerance), with every loop closed to 1e-8 m. MuJoCo reaches micrometres only at 0.25 ms steps (4× real time, 0.0031 mm). With MuJoCo's default constraint settings the platform is 43 mm off at any step size.

All errors are measured against forward kinematics from the leg lengths, which needs no dynamics and no solver. The ManifoldsX figure was first reported as 0.0004 mm; see the correction below.

![Speed vs accuracy](stewart_work_precision.png)

## Test setup

- **Model:** two-stage Stewart platform from the ManifoldsX examples: 26 moving bodies, 24 spherical and 12 prismatic joints, and all 12 leg lengths driven by tables. 18 s run.
- **Leg tables:** spline-smoothed to 1 ms, used identically by both solvers.
- **ManifoldsX:** index-3 HHT with accurate Newton and error control (LTE 1e-5, steps up to 3 ms). Joints and leg drives are exact constraints.
- **MuJoCo 3.15 twin:** same bodies, masses, inertias and joint points, from the same model data.
  - **Loops:** each closed with an equality connect.
  - **Legs:** each driven by a joint equality whose target follows the table. The equality is coupled to a virtual clock joint, so it sees the target's velocity as well as its position (details under Findings).
  - **Stepping:** a plain C loop around `mj_step` that refreshes the targets every step.
- **Constraint settings:**
  - Stiffest: time constant = 2 × step, MuJoCo's lower limit; solimp 0.9999.
  - MuJoCo default: time constant 20 ms; solimp 0.9 / 0.95.
- **Metrics:** worst case over the run of loop gap, leg-length error and top-platform position error. The platform error is measured against forward kinematics: with every joint satisfied, each platform's pose is a pure function of its six leg lengths, so `reference/fk_reference.py` solves for it directly at every saved time. Speed is single-core wall time.

## Results

| Setup | Speed (× real time) | Loop gap (mm) | Leg-length error (mm) | Platform error (mm) |
| --- | --- | --- | --- | --- |
| ManifoldsX, accurate + LTE 1e-5 | 13–14 | 0.00001 | exact | 0.00002 |
| ManifoldsX, file settings, 1 ms | 8–9 | 0.006 | exact | 0.0097 |
| MuJoCo implicitfast, 2 ms, stiffest | 31 | 0.006 | 0.20 | 0.33 |
| MuJoCo implicitfast, 1 ms, stiffest | 16.6 | 0.0017 | 0.069 | 0.11 |
| MuJoCo implicitfast, 0.5 ms, stiffest | 7.9 | 0.0004 | 0.017 | 0.028 |
| MuJoCo implicitfast, 0.25 ms, stiffest | 4.0 | 0.0001 | 0.0016 | 0.0031 |
| MuJoCo RK4, 1 ms / 0.25 ms, stiffest | 4.2 / 1.0 | 0.0008 / 0.00006 | 0.13 / 0.007 | 0.21 / 0.011 |
| MuJoCo implicitfast, 1 ms, default settings | 17.7 | 6.0 | 7.1 | 43 |
| MuJoCo implicitfast, 1 ms, target-only leg drive, stiffest | 16.6 | 0.0015 | 1.4 | 2.0 |
| MuJoCo implicitfast, 1 ms, servo legs (first version) | 16.1 | 4.7 | 1.3 | 16 |

## Findings

- **What it took to make MuJoCo's legs exact.** MuJoCo has no time-driven joint constraint, so three settings had to work together:
  - **Velocity-consistent drive.** The usual recipe moves the equality's target each step. MuJoCo's constraint stabilization then damps the leg's velocity towards zero rather than towards the target's, so the leg trails by 1.4 mm. Coupling the equality to a heavy virtual clock slider, with a cubic of the table refreshed each step, gives the constraint the target velocity and removes that lag.
  - **Stiffest time constant.** The 20 ms default leaves 7.1 mm on the legs and 43 mm on the platform at every step from 0.25 to 2 ms, with either integrator.
  - **Hard solimp.** Together with the stiffest time constant, solimp 0.9999 brings the platform to 0.11 mm at 1 ms.
- **Why MuJoCo's error still depends on the step.** MuJoCo enforces constraints at acceleration level and leaves out the target's acceleration and the joints' velocity-product terms, so each constraint trails by about acceleration × time constant². The time constant can't go below 2 × step, so the error falls with step² (0.11 → 0.028 → 0.003 mm). ManifoldsX solves joint positions at every step, so its error does not depend on step size.
- **Constraint legs made MuJoCo more robust.** implicitfast now runs at 2 ms: 31× real time with 0.33 mm error. That is MuJoCo's fastest useful point: 2.3× ManifoldsX's speed at about 800× its error. The servo version diverged at 2 ms.
- **RK4 doesn't help here.** It hits the same constraint limit at 4× the cost per step.
- **Twin fix.** Body poses had been exported with 6 significant digits, which put a 5 µm floor under every MuJoCo number. They are now exported at full precision; the earlier mm-level results don't change.
- **Model fix.** With the original 20 ms linear leg tables, ManifoldsX failed below about 1 ms steps: each table point is a velocity jump, so the leg force spikes like 1/dt. Smoothed tables fixed it and cut rejected steps from 86 to 1. Table motion laws should be cubic by default.
- **Correction (2026-10-13).** The virtual clock was first 1e12 kg, which made MuJoCo's Newton solver return without iterating. At 1e6 kg, platform error and speed are unchanged; MuJoCo's loop gaps and leg errors in the stiffest implicitfast rows came out smaller, and the table shows the corrected values.
- **Correction (2026-10-16): the ManifoldsX error was overstated about 20×.** It was first scored against ManifoldsX's own 0.25 ms run through a cubic spline. The leg tables are piecewise linear at 1 ms, so the platform velocity has small kinks every millisecond and the spline overshoots between samples. That artifact alone produced the 0.0004 mm (3.9e-7 m) reported before. Against forward kinematics the accurate run is 1.8e-8 m, and the 0.25 ms run itself is 8.6e-8 m, at its Newton tolerance. The file-settings run (1 ms, Newton tolerance 1e-6) is 9.7e-6 m. MuJoCo's numbers are unchanged: they agree with forward kinematics to three digits, because they are far above the artifact.
- **What the error measures.** ManifoldsX solves the joint and drive positions at every step, so its error is set by its Newton tolerance and doesn't grow with the step. MuJoCo's error is set by its constraint stabilization and falls with the square of the step.
- **Caveats.**
  - Single model, single machine. Re-run on a second machine on 2026-10-16 (2-core cloud workspace, MuJoCo 3.15.0): ManifoldsX accurate 13.6× real time, MuJoCo implicitfast 1 ms 15.7×, 0.25 ms 4.0× (medians of 3–5 runs), with the same errors.
  - Prescribed motion. The leg lengths follow tables, so the exact answer is pure kinematics. MuJoCo has no built-in time-driven joint constraint, and the clock-joint drive is my construction from standard MuJoCo features. The test says nothing about contact, force-driven motion, or throughput over many parallel environments, which MuJoCo is built for.

## Package and reproduction

- `model/`: the original example, the spline-smoothed model both solvers ran, and `smooth_tables.py`.
- `manifoldsx/`: `run_stewart.cpp` (JSON runner) and `score_mx.py` (platform error of a ManifoldsX run against the 0.25 ms run).
- `reference/fk_reference.py`: the independent reference. Forward kinematics of both stages from the leg lengths, scored against any trajectory file from either solver.
- `mujoco/`:
  - `mj_stewart.py`: the twin, with three leg drives (`MJS_DRIVE=eqv|eq|servo`).
  - `mj_drive.c`: the C stepping loop.
  - `sweep.sh`: the full sweep.
  - `plot_stewart_wp.py`: the chart.
- `results/`: `summary.csv`, the full MuJoCo sweep, and the ManifoldsX reference and accurate-mode trajectories.
- `run_all.sh`: reruns the table. Timings vary about ±10% between runs.
