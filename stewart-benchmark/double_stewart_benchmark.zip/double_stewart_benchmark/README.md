# Double Stewart benchmark: ManifoldsX vs MuJoCo

On the two-stage Stewart platform, ManifoldsX runs at 13–14× real time and tracks the exact solution to 0.00002 mm (its Newton tolerance), with every loop closed to 1e-8 m. The MuJoCo twin uses constraint-driven legs and the stiffest constraint settings MuJoCo accepts. At 1 ms steps it runs at 16.6× real time with 0.11 mm platform error. It reaches micrometres only at 0.25 ms steps (4× real time). Errors are measured against forward kinematics from the leg lengths (`reference/fk_reference.py`); the ManifoldsX number was first reported as 0.0004 mm, a scoring artifact explained in `REPORT.md`.

- `REPORT.md`: the one-page summary.
- `stewart_work_precision.png`: the speed-vs-accuracy chart.
- `results/summary.csv`: every row of the report table.

## Contents

- `model/`
  - `stewart_2m_two_stage_serial_full_joint_big_showcase_motion_may2.json`: the original ManifoldsX example, with linear leg tables at 20 ms.
  - `stewart_spline1ms.json`: the same model with leg tables spline-smoothed to 1 ms. Both solvers use this one.
  - `smooth_tables.py`: regenerates the smoothed model (`python smooth_tables.py in.json out.json 0.001`).
- `manifoldsx/`
  - `run_stewart.cpp`: runner for ManifoldsX JSON models. It needs the solver tree with the contact-tangent changes, which provide `setAccurateNewton` and the attempt counters.
    - `run_stewart model.json accurate [T]`: accurate Newton + HHT LTE 1e-5, steps up to 3 ms.
    - `run_stewart model.json file [T]`: the model file's own settings. `RS_DT` overrides the step.
    - `run_stewart model.json <mode> T bodies.json traj.csv [dt]`: also writes body data (full precision) and platform trajectories. `RS_OUTDT` sets the trajectory sampling (default 10 ms; tiny = every step).
  - `score_mx.py traj.csv`: max platform error of a ManifoldsX run against the 0.25 ms run (linear interpolation).
- `reference/`
  - `fk_reference.py traj.csv [...]`: the independent reference. Solves the forward kinematics of both stages from the leg lengths at every saved time and prints each trajectory's max platform error against it. Works on trajectory files from either solver (`mj_stewart.py ... T traj.csv` writes MuJoCo's).
- `mujoco/`: needs `pip install mujoco scipy` and a C compiler.
  - `mj_stewart.py`: the MuJoCo 3.15 twin, built from the ManifoldsX JSON and `bodies.json`. Usage: `python mj_stewart.py <dt> <implicitfast|RK4> [equality_timeconst=0.02] [kp=1e8] [T=18]`. It prints speed, loop gap, leg error and platform error as JSON. Environment variables:
    - `MJS_DRIVE` = `eqv` (default), `eq` or `servo`: the leg drive (see below).
    - `MJS_DRIVE_TC`: time constant of the leg constraints (default: same as the loops).
    - `MJS_SOLIMP`: solimp for all equality constraints (default MuJoCo's `0.9 0.95 0.001 0.5 2`).
  - `mj_drive.c`: a plain C loop around `mj_step`. It refreshes the leg targets every step, so that work costs no Python time. `run_all.sh` builds it; by hand:
    `gcc -O2 -o mj_drive mj_drive.c -I$MJ/include $MJ/libmujoco.so.* -Wl,-rpath,$MJ`, with `MJ` = the mujoco Python package folder.
  - `sweep.sh`: the full sweep (integrators × steps × constraint settings, plus the servo version). It writes `../results/mujoco_sweep.jsonl`.
  - `plot_stewart_wp.py sweep.jsonl out.png`: the chart.
  - `bodies.json`: body masses, inertias and poses, dumped from ManifoldsX at full precision.
- `results/`
  - `summary.csv`.
  - `mujoco_sweep.jsonl`.
  - `mx_tight_reference_traj.csv`: the reference, ManifoldsX at a fixed 0.25 ms step, every step.
  - `mx_accurate_traj.csv`: the accurate-mode run, every step.
  - `mujoco_clockfix_rerun.jsonl`: the constraint-drive rows re-run after the clock fix (2026-10-13, on a busier machine, so its speeds read about 30% low).

## Reproduce

```
cd mujoco && RUNNER=/path/to/run_stewart ../run_all.sh
```
Without `RUNNER`, the ManifoldsX part scores the saved trajectory instead. Timings vary about ±10% between runs on the same machine.

## How the MuJoCo twin is built

- **Joints:** the leg-base spherical joints become MuJoCo ball joints and the leg sliders become slide joints, which makes a tree.
- **Loops:** each top spherical joint is an equality `connect`, MuJoCo's standard way to close a kinematic loop.
- **Leg drive.** MuJoCo has no time-driven joint constraint, so there are three options:
  - `eqv`: a joint equality per leg, coupling the slide to a virtual clock slider. The clock is a separate 1e6 kg body (at 1e12 kg MuJoCo's Newton solver returns without iterating; `meaninertia` is set as without the clock), reset each step to τ = 0 moving at 1 m/s. The equality's polynomial is the cubic Taylor expansion of the leg table around the current time, refreshed every step. The constraint therefore sees the target's position and velocity, and RK4 stages see the target at their own time.
  - `eq`: a joint equality with only its target position refreshed every step, the usual recipe. MuJoCo's stabilization damps the leg velocity towards zero, so the leg lags the target.
  - `servo`: a position actuator per leg (kp, with kv near critical). This was the first version of the twin.
- **Accuracy:** with all constraints satisfied the platform pose is a pure function of the leg lengths, so the exact answer is forward kinematics, and the platform error measures constraint error in both solvers. `reference/fk_reference.py` computes it without either solver. `mj_stewart.py` also prints an error against the ManifoldsX 0.25 ms run, which agrees with forward kinematics to three digits for every MuJoCo row.
