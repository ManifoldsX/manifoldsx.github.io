// Run a ManifoldsX JSON model (Double Stewart) with either the file's own
// settings or the accurate baseline (accurate Newton + HHT LTE 1e-5, 3 ms ceiling).
// Usage: run_stewart model.json [file|accurate] [T]
#include "mbd_model_interface_json.hpp"
#include "mbd_model_builder_bridge_into.hpp"
#include "SimManagerAbs.hpp"
#include <chrono>
#include <cstdio>
#include <string>
#include <fstream>
#include <iomanip>
#include <algorithm>
#include <vector>
#include <cstdlib>
int main(int argc, char** argv) {
    const std::string path = argv[1];
    const std::string mode = argc > 2 ? argv[2] : "file";
    mbd::app::ModelInterface doc = mbd::app::loadJsonFile(path);
    const double T = argc > 3 ? std::stod(argv[3]) : doc.sim.t1;
    mbd::SimulationManager sim; sim.setConsoleOutput(std::getenv("RS_VERBOSE") != nullptr); sim.setProgressReportCount(0); sim.disableOutput();
    mbd::app::ModelInterfaceToMbdBridgeInto bridge(sim.model());
    bridge.buildInto(doc, false);
    sim.setGravity(doc.sim.gravity);
    sim.setIntegrationMode(mbd::IntegrationMode::INDEX_3_DAE);
    if (doc.sim.has_hht_alpha) sim.setHHTAlpha(doc.sim.hht_alpha);
    sim.setUseLineSearch(true);
    if (mode == "file") {
        sim.setTimeStep(std::getenv("RS_DT") ? std::atof(std::getenv("RS_DT")) : doc.sim.dt);
        if (doc.sim.has_newton_max_iterations) sim.setNewtonMaxIterations(doc.sim.newton_max_iterations);
        if (doc.sim.has_newton_abs_tol_accel) sim.setNewtonAbsTolAccel(doc.sim.newton_abs_tol_accel);
        if (doc.sim.has_newton_abs_tol_pos) sim.setNewtonAbsTolPos(doc.sim.newton_abs_tol_pos);
        if (doc.sim.has_newton_refresh_m_frequency) sim.setNewtonRefreshMFrequency(doc.sim.newton_refresh_m_frequency);
    } else {
        sim.setTimeStep(3e-3);
        sim.setNewtonMaxIterations(20); sim.setNewtonAbsTolAccel(1e-8); sim.setNewtonAbsTolPos(1e-8);
        sim.setVelocityProjectionEnabled(false);
        sim.setAccurateNewton(true);
        if (std::getenv("RS_NOGEO")) sim.setConstraintStiffnessEnabled(false);
        if (std::getenv("RS_NOVERIFY")) sim.setVerifiedAcceptance(false);
        if (std::getenv("RS_NOBLEND")) sim.setIndex3BlendedReaction(false);
        mbd::IntegrationErrorTolerances tol; tol.position_absolute = tol.orientation_absolute = tol.relative = 1e-5;
        sim.setIntegrationErrorMethod(mbd::IntegrationErrorMethod::HhtLte);
        sim.setIntegrationErrorTolerances(tol); sim.setIntegrationErrorControlEnabled(mode == "accurate");
        if (mode == "tight") sim.setTimeStep(argc > 6 ? std::stod(argv[6]) : 2.5e-4);
    }
    sim.finalize();
    // Dump body properties per JSON part id, for building the MuJoCo twin.
    if (argc > 4) {
        std::ofstream jf(argv[4]);
        jf << std::setprecision(17);   // full precision: the MuJoCo twin is built from these poses
        jf << "{\"parts\":[";
        bool first = true;
        for (const auto& kv : bridge.partMap()) {
            const auto& b = sim.model()->body(kv.second);
            Eigen::Quaterniond qq(b.R_WB0);
            jf << (first ? "" : ",") << "{\"id\":" << kv.first << ",\"fixed\":" << (b.isFixed ? 1 : 0)
               << ",\"mass\":" << b.mass << ",\"I\":[";
            for (int r = 0; r < 3; ++r) for (int c = 0; c < 3; ++c) jf << (r || c ? "," : "") << b.I_body(r, c);
            jf << "],\"r\":[" << b.r_WB0.x() << "," << b.r_WB0.y() << "," << b.r_WB0.z() << "],\"q\":["
               << qq.w() << "," << qq.x() << "," << qq.y() << "," << qq.z() << "]}";
            first = false;
        }
        jf << "]}\n";
    }
    // Platform trajectories (part ids 2 and 3 if present) every 10 ms.
    std::vector<std::pair<long, mbd::BodyId>> plats;
    for (const auto& kv : bridge.partMap()) if (!sim.model()->body(kv.second).isFixed && (kv.first == 2 || kv.first == 3)) plats.push_back({kv.first, kv.second});
    std::sort(plats.begin(), plats.end(), [](auto& a, auto& b){ return a.first < b.first; });
    FILE* tf = argc > 5 ? std::fopen(argv[5], "w") : nullptr;
    double next_out = 0.0;
    const double out_dt = std::getenv("RS_OUTDT") ? std::atof(std::getenv("RS_OUTDT")) : 0.01;   // trajectory sampling
    auto writeTraj = [&]() {
        if (!tf) return;
        std::fprintf(tf, "%.9f", sim.time());
        const auto sv = sim.stateView();
        for (auto& pb : plats) { const Eigen::Vector3d r = sv.r(pb.second); const Eigen::Vector4d q = sv.quatWXYZ(pb.second);
            std::fprintf(tf, ",%.9f,%.9f,%.9f,%.9f,%.9f,%.9f,%.9f", r.x(), r.y(), r.z(), q[0], q[1], q[2], q[3]); }
        std::fprintf(tf, "\n");
    };
    if (tf) { std::fprintf(tf, "t"); for (auto& pb : plats) for (const char* c : {"x","y","z","qw","qx","qy","qz"}) std::fprintf(tf, ",p%ld_%s", pb.first, c); std::fprintf(tf, "\n"); writeTraj(); next_out = out_dt; }
    std::printf("bodies=%d  q=%d  v=%d  constraints=%d\n", (int)sim.model()->numBodies(),
                (int)sim.state().q.size(), (int)sim.state().v.size(), (int)sim.state().lambda.size());
    double max_phi = 0, max_phidot = 0, hmin = 1, hmax = 0; long steps = 0;
    const auto w0 = std::chrono::steady_clock::now();
    while (sim.time() < T - 1e-9) {
        const double t0 = sim.time();
        if (!sim.step()) { std::printf("FAILED at t=%.4f status=%s\n", sim.time(), sim.lastIntegrationError().status.c_str()); break; }
        ++steps; const double h = sim.time() - t0; hmin = std::min(hmin, h); hmax = std::max(hmax, h);
        max_phi = std::max(max_phi, sim.getPhi().lpNorm<Eigen::Infinity>());
        max_phidot = std::max(max_phidot, sim.getPhiDot().lpNorm<Eigen::Infinity>());
        if (tf && sim.time() >= next_out - 1e-9) { writeTraj(); next_out += out_dt; }
    }
    if (tf) std::fclose(tf);
    const double wall = std::chrono::duration<double>(std::chrono::steady_clock::now() - w0).count();
    std::printf("mode=%s T=%.2f wall=%.2f s (x%.2f real time) steps=%ld h=[%.2e, %.2e] newton/attempt=%.2f rejects=%llu max|Phi|=%.2e max|PhiDot|=%.2e\n",
        mode.c_str(), sim.time(), wall, sim.time() / wall, steps, hmin, hmax,
        (double)sim.newtonIterationsAllAttempts() / std::max<unsigned long long>(1, sim.integratorStepAttempts()),
        (unsigned long long)sim.integrationErrorRejectedTrials(), max_phi, max_phidot);
}
