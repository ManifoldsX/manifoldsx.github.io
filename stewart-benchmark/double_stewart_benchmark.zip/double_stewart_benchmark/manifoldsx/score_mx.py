"""Max top-platform position error of a ManifoldsX trajectory against the fixed 0.25 ms run
(every step saved; linearly interpolated to the run's own output times). A cubic spline overshoots
at the 1 ms kinks of the piecewise-linear leg tables and inflates the error to ~4e-7 m; use
../reference/fk_reference.py for the independent reference.
Usage: python score_mx.py run_traj.csv [reference.csv]"""
import sys, os
import numpy as np
run = np.genfromtxt(sys.argv[1], delimiter=',', names=True)
ref = np.genfromtxt(sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'results', 'mx_tight_reference_traj.csv'), delimiter=',', names=True)
run = run[run['t'] <= ref['t'][-1] + 1e-12]
err = 0.0
for p in (2, 3):
    rp = np.stack([np.interp(run['t'], ref['t'], ref[f'p{p}_{c}']) for c in 'xyz'], axis=1)
    mp = np.stack([run[f'p{p}_{c}'] for c in 'xyz'], axis=1)
    err = max(err, float(np.linalg.norm(mp - rp, axis=1).max()))
print(f'{sys.argv[1]}: {len(run)} samples, max platform position error {err:.2e} m')
