"""MuJoCo twin of the ManifoldsX double Stewart platform.
Same bodies (mass, inertia, initial pose dumped from ManifoldsX), same joint points.
Tree: base ball joints + leg slide joints; each leg closes its loop on the platform
with an equality 'connect' (MuJoCo's way to close kinematic loops).

Leg drive (MJS_DRIVE):
  eqv   (default) leg length is a constraint, like ManifoldsX: a joint equality per leg
        couples the slide to a virtual clock joint (1e6 kg) through a cubic of the table around the
        current time, refreshed every step. The constraint then sees the target's position
        and velocity (and RK4 stages see the target at their own time).
  eq    joint equality with only the target position refreshed every step (the usual
        MuJoCo recipe). Its stabilisation damps the leg velocity towards zero, not towards
        the target velocity, so it lags.
  servo stiff position actuator per leg (kp below), the first version of this twin.
eqv/eq are stepped by mj_drive (plain C loop) so per-step eq_data updates cost no Python
time; servo uses mujoco.rollout. Both are C loops around mj_step.

Usage: python mj_stewart.py dt integrator [eq_timeconst=0.02] [kp=1e8] [T=18] [traj.csv]
Env:   MJS_DRIVE, MJS_DRIVE_TC (drive solref time constant, default = eq_timeconst),
       MJS_SOLIMP (all equalities, default MuJoCo's '0.9 0.95 0.001 0.5 2'),
       MJS_MODEL, MJS_REF, MJS_BODIES, MJS_DRIVER (path to mj_drive)"""
import sys, json, time, os, subprocess, tempfile
import numpy as np
import mujoco
from mujoco import rollout
from scipy.interpolate import CubicSpline

dt = float(sys.argv[1]); integ = sys.argv[2]
EQ_TC = float(sys.argv[3]) if len(sys.argv) > 3 else 0.02      # MuJoCo default solref time constant
KP = float(sys.argv[4]) if len(sys.argv) > 4 else 1e8
T = float(sys.argv[5]) if len(sys.argv) > 5 else 18.0
traj_out = sys.argv[6] if len(sys.argv) > 6 else None
DRIVE = os.environ.get('MJS_DRIVE', 'eqv')
DRIVE_TC = float(os.environ.get('MJS_DRIVE_TC', EQ_TC))
SOLIMP = os.environ.get('MJS_SOLIMP', '0.9 0.95 0.001 0.5 2')
HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.environ.get('MJS_MODEL', os.path.join(HERE, '..', 'model', 'stewart_spline1ms.json'))
REF = os.environ.get('MJS_REF', os.path.join(HERE, '..', 'results', 'mx_tight_reference_traj.csv'))
BODIES = os.environ.get('MJS_BODIES', os.path.join(HERE, 'bodies.json'))
DRIVER = os.environ.get('MJS_DRIVER', os.path.join(HERE, 'mj_drive'))
doc = json.load(open(MODEL)); bod = {p['id']: p for p in json.load(open(BODIES))['parts']}
parts = {p['id']: p for p in doc['parts']}; markers = {m['id']: m for m in doc['markers']}

def quat_to_R(q):
    w, x, y, z = q / np.linalg.norm(q)
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
def R_to_quat(R):
    q = np.empty(4); mujoco.mju_mat2Quat(q, R.flatten()); return q
def pose(pid):
    b = bod[pid]; return np.array(b['r']), quat_to_R(np.array(b['q']))
def marker_world(mid):
    m = markers[mid]; r, R = pose(m['part_id'])
    return r + R @ np.array(m['part_T_marker']['r']), R @ quat_to_R(np.array(m['part_T_marker']['q']))
def v3(a): return ' '.join(f'{x:.12g}' for x in a)

# Legs: base spherical (a: base part, b: sleeve), slider (a: sleeve, b: rod), top spherical (a: rod, b: platform).
J = {j['id']: j for j in doc['joints']}
legs = []
js = sorted(J.values(), key=lambda j: j['id'])
for i in range(0, len(js), 3):
    base, slide, top = js[i], js[i+1], js[i+2]
    assert base['kind'] == 'Spherical' and slide['kind'] == 'Prismatic' and top['kind'] == 'Spherical'
    sleeve = markers[base['marker_b']]['part_id']; rod = markers[slide['marker_b']]['part_id']
    legs.append(dict(base_part=markers[base['marker_a']]['part_id'], sleeve=sleeve, rod=rod,
                     base_marker=base['marker_a'], slide_a=slide['marker_a'], slide_b=slide['marker_b'],
                     top_rod_marker=top['marker_a'], top_plat_marker=top['marker_b'],
                     plat=markers[top['marker_b']]['part_id'], slide_joint=slide['id']))
motion_of = {}
for m in doc['motions']:
    motion_of[(m['marker_a'], m['marker_b'])] = np.array(m['scalar_law']['table'])

def inertial(pid):
    b = bod[pid]; I = np.array(b['I']).reshape(3, 3)
    return (f'<inertial pos="0 0 0" mass="{b["mass"]:.12g}" '
            f'fullinertia="{I[0,0]:.12g} {I[1,1]:.12g} {I[2,2]:.12g} {I[0,1]:.12g} {I[0,2]:.12g} {I[1,2]:.12g}"/>')

def body_xml(pid, parent_pid, joint_xml, children_xml):
    r, R = pose(pid)
    if parent_pid is None: pr, pR = np.zeros(3), np.eye(3)
    else: pr, pR = pose(parent_pid)
    rel_r = pR.T @ (r - pr); rel_R = pR.T @ R
    return (f'<body name="b{pid}" pos="{v3(rel_r)}" quat="{v3(R_to_quat(rel_R))}">{inertial(pid)}'
            f'{joint_xml}{children_xml}</body>')

def leg_xml(L):
    sr, sR = pose(L['sleeve']); rr, rR = pose(L['rod'])
    xb, _ = marker_world(L['base_marker'])
    ball = f'<joint name="ball{L["sleeve"]}" type="ball" pos="{v3(sR.T @ (xb - sr))}"/>'
    _, Ra = marker_world(L['slide_a'])
    axis_rod = rR.T @ Ra[:, 2]
    slide = f'<joint name="slide{L["slide_joint"]}" type="slide" axis="{v3(axis_rod)}" pos="0 0 0"/>'
    rod = body_xml(L['rod'], L['sleeve'], slide, '')
    return body_xml(L['sleeve'], None if parts[L['base_part']]['is_ground'] else L['base_part'], ball, rod)

plat_ids = sorted({L['plat'] for L in legs})
world_children = ''
for L in legs:
    if parts[L['base_part']]['is_ground']: world_children += leg_xml(L)
for p in plat_ids:
    kids = ''.join(leg_xml(L) for L in legs if L['base_part'] == p)
    world_children += body_xml(p, None, '<freejoint/>', kids)

eq = ''
for L in legs:
    xr, _ = marker_world(L['top_rod_marker']); rr, rR = pose(L['rod'])
    eq += (f'<connect body1="b{L["rod"]}" body2="b{L["plat"]}" anchor="{v3(rR.T @ (xr - rr))}" '
           f'solref="{EQ_TC} 1" solimp="{SOLIMP}"/>')
act = ''
if DRIVE == 'servo':
    kv = 2.0 * np.sqrt(KP * 400.0)        # about critical for a leg plus its share of platform
    act = ''.join(f'<position joint="slide{L["slide_joint"]}" kp="{KP:g}" kv="{kv:g}" ctrllimited="false"/>' for L in legs)
elif DRIVE in ('eq', 'eqv'):
    j2 = ' joint2="clock"' if DRIVE == 'eqv' else ''
    eq += ''.join(f'<joint joint1="slide{L["slide_joint"]}"{j2} polycoef="0 0 0 0 0" '
                  f'solref="{DRIVE_TC} 1" solimp="{SOLIMP}"/>' for L in legs)
    if DRIVE == 'eqv':   # virtual clock: separate heavy slider, no gravity along its axis
        # Heavy enough that constraint reactions barely move it (it is reset every step anyway), light
        # enough for MuJoCo's Newton solver: at 1e12 kg it returns without iterating.
        world_children += ('<body name="clock" pos="0 0 -10"><joint name="clock" type="slide" axis="1 0 0"/>'
                           '<inertial pos="0 0 0" mass="1e6" diaginertia="1 1 1"/></body>')
else:
    raise SystemExit('MJS_DRIVE must be eqv, eq or servo')
xml = (f'<mujoco><option timestep="{dt}" integrator="{integ}" gravity="0 0 -9.81"/>'
       f'<worldbody>{world_children}</worldbody><equality>{eq}</equality><actuator>{act}</actuator></mujoco>')
model = mujoco.MjModel.from_xml_string(xml)
if DRIVE == 'eqv':   # keep the solver tolerance scale (mean inertia) as it is without the clock
    mi = (model.stat.meaninertia * model.nv - 1e6) / (model.nv - 1)
    xml = xml.replace('<mujoco>', f'<mujoco><statistic meaninertia="{mi:.9g}"/>', 1)
    model = mujoco.MjModel.from_xml_string(xml)
data = mujoco.MjData(model)
mujoco.mj_resetData(model, data); mujoco.mj_forward(model, data)
nq, nv = model.nq, model.nv

# Leg-length targets: table(t) - table(0).
nstep = int(round(T / dt))
tables = [motion_of[(L['slide_a'], L['slide_b'])] for L in legs]
def target(t):            # same piecewise-linear table ManifoldsX follows
    return np.stack([np.interp(t, tb[:, 0], tb[:, 1]) - tb[0, 1] for tb in tables], axis=-1)
stride = max(1, int(round(0.01 / dt)))

if DRIVE == 'servo':
    tt = (np.arange(nstep) + 1) * dt          # held at the end-of-step value
    ctrl = target(tt)[None]
    spec = mujoco.mjtState.mjSTATE_FULLPHYSICS
    s0 = np.empty(mujoco.mj_stateSize(model, spec)); mujoco.mj_getState(model, data, s0, spec)
    rollout.rollout(model, data, s0[None], ctrl[:, :min(10, nstep)], nstep=min(10, nstep))
    wall = 1e300
    for _ in range(2):
        t0 = time.perf_counter(); st, _ = rollout.rollout(model, data, s0[None], ctrl, nstep=nstep); wall = min(wall, time.perf_counter() - t0)
    st = st[0]
    finite = bool(np.all(np.isfinite(st[:, 1:1+nq]))) and data.warning[mujoco.mjtWarning.mjWARN_BADQACC].number == 0
    idx = np.arange(stride - 1, nstep, stride)
    times, Q = st[idx, 0], st[idx, 1:1+nq]
else:
    tk = np.arange(nstep) * dt                # row k is applied before step k (time t_k)
    if DRIVE == 'eq':
        rows_drv = target(tk)
    else:   # cubic Taylor of the table around t_k, in tau = time since step start
        rows_drv = np.empty((nstep, len(legs), 4))
        for i, tb in enumerate(tables):
            S = CubicSpline(tb[:, 0], tb[:, 1] - tb[0, 1], bc_type='clamped')
            rows_drv[:, i, 0] = np.interp(tk, tb[:, 0], tb[:, 1]) - tb[0, 1]
            for o in (1, 2, 3):
                rows_drv[:, i, o] = S(tk, o) / [1, 1, 2, 6][o]
        rows_drv = rows_drv.reshape(nstep, -1)
    with tempfile.TemporaryDirectory() as td:
        xf, df, of = (os.path.join(td, n) for n in ('m.xml', 'd.bin', 'o.bin'))
        open(xf, 'w').write(xml); np.ascontiguousarray(rows_drv, dtype=np.float64).tofile(df)
        res = subprocess.run([DRIVER, xf, df, {'eq': '1', 'eqv': '2'}[DRIVE], str(nstep), str(rows_drv.shape[1]),
                              str(stride), of, str(len(legs)), 'clock', '2'], capture_output=True, text=True)
        if res.returncode: raise SystemExit(res.stderr)
        raw = np.fromfile(of)
    wall, bad = raw[-2], raw[-1]
    rec = raw[:-2].reshape(-1, 1 + nq)
    times, Q = rec[:, 0], rec[:, 1:]
    finite = bool(np.all(np.isfinite(Q))) and bool(bad == 0)

# Loop opening, leg-length tracking error, platform poses every 10 ms.
d2 = mujoco.MjData(model)
slide_adr = [model.jnt_qposadr[mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, f'slide{L["slide_joint"]}')] for L in legs]
anch = []
for L in legs:
    xr, _ = marker_world(L['top_rod_marker']); rr, rR = pose(L['rod'])
    m = markers[L['top_plat_marker']]
    anch.append((mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, f'b{L["rod"]}'), rR.T @ (xr - rr),
                 mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, f'b{L["plat"]}'), np.array(m['part_T_marker']['r'])))
pb = [mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_BODY, f'b{p}') for p in plat_ids]
max_gap = max_track = 0.0; rows = []
if finite:
    tgt = target(times)
    for k in range(len(times)):
        d2.qpos[:] = Q[k]; mujoco.mj_kinematics(model, d2)
        for b1, a1, b2, a2 in anch:
            p1 = d2.xpos[b1] + d2.xmat[b1].reshape(3, 3) @ a1; p2 = d2.xpos[b2] + d2.xmat[b2].reshape(3, 3) @ a2
            max_gap = max(max_gap, float(np.linalg.norm(p1 - p2)))
        max_track = max(max_track, float(np.max(np.abs(Q[k, slide_adr] - tgt[k]))))
        row = [times[k]]
        for b in pb: row += list(d2.xpos[b]) + list(d2.xquat[b])
        rows.append(row)
if traj_out and finite:
    np.savetxt(traj_out, np.array(rows), delimiter=',', comments='', fmt='%.9g',
               header='t,' + ','.join(f'p{p}_{c}' for p in plat_ids for c in ('x','y','z','qw','qx','qy','qz')))
plat_err = None
if finite and os.path.exists(REF):
    ref = np.genfromtxt(REF, delimiter=',', names=True); R = np.array(rows)
    plat_err = 0.0
    for i, p in enumerate(plat_ids):
        rp = np.stack([np.interp(R[:, 0], ref['t'], ref[f'p{p}_{c}']) for c in 'xyz'], axis=1)
        mp = R[:, 1 + 7*i: 4 + 7*i]
        plat_err = max(plat_err, float(np.max(np.linalg.norm(mp - rp, axis=1))))
print(json.dumps(dict(solver='MuJoCo ' + mujoco.__version__, integrator=integ, dt=dt, drive=DRIVE, eq_tc=EQ_TC,
                      drive_tc=DRIVE_TC if DRIVE != 'servo' else None, kp=KP if DRIVE == 'servo' else None,
                      solimp=SOLIMP, T=T, wall=round(float(wall), 4), rtf=round(T / float(wall), 2), nv=nv, n_eq=int(model.neq),
                      stable=finite, max_loop_gap_m=max_gap if finite else None,
                      max_leg_track_err_m=max_track if finite else None, max_platform_pos_err_m=plat_err)))
