#!/bin/bash
# MuJoCo twin sweep. Leg drive as a constraint (eqv, eq) over integrators x steps x constraint
# settings, plus the earlier servo-driven configurations for comparison.
# Run from mujoco/. Defaults: ../model, ../results reference, bodies.json, ./mj_drive.
HARD="0.9999 0.9999 0.001 0.5 2"; DEF="0.9 0.95 0.001 0.5 2"
out=${1:-../results/mujoco_sweep.jsonl}; : > $out
run() { python mj_stewart.py "$@" >> $out || echo "{\"failed\": \"$*\"}" >> $out; }
for integ in implicitfast RK4; do
  for dt in 0.002 0.001 0.0005 0.00025; do
    tc2=$(python -c "print(2*$dt)")
    MJS_DRIVE=eqv MJS_SOLIMP="$DEF"  run $dt $integ 0.02 1e8 18    # MuJoCo default constraint settings
    MJS_DRIVE=eqv MJS_SOLIMP="$DEF"  run $dt $integ $tc2 1e8 18    # stiffest solref MuJoCo allows (2 dt)
    MJS_DRIVE=eqv MJS_SOLIMP="$HARD" run $dt $integ $tc2 1e8 18    # + hard solimp
    MJS_DRIVE=eq  MJS_SOLIMP="$HARD" run $dt $integ $tc2 1e8 18    # usual recipe (target only), hardest
  done
done
export MJS_DRIVE=servo MJS_SOLIMP="$DEF"                           # first version of the twin
run 0.002 implicitfast 0.02 1e8 18; run 0.001 implicitfast 0.02 1e8 18; run 0.0005 implicitfast 0.002 1e8 18
run 0.00025 implicitfast 0.002 1e9 18; run 0.0005 RK4 0.02 1e8 18; run 0.0005 RK4 0.002 1e8 18
