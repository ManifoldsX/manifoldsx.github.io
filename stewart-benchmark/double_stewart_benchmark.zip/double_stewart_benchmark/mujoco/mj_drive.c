// Plain C stepping loop for the MuJoCo Stewart twin, so a drive that changes
// eq_data every step is timed without Python overhead (same role as rollout).
// usage: mj_drive model.xml drive.bin mode nstep nval stride out.bin [eq0] [clock_joint] [repeats]
//   drive.bin: nstep*nval doubles, row k is applied before step k
//   mode 0 (servo): ctrl[i]                = row[i]
//   mode 1 (eq):    eq_data[eq0+i][0]      = row[i]               (joint equality, target only)
//   mode 2 (eqv):   eq_data[eq0+i][0..3]   = row[4i..4i+3]        (joint equality to a clock joint:
//                   local cubic in tau = clock position; clock reset to tau=0, rate 1 each step)
//   out.bin: for every stride-th step, [time, qpos(nq)]; then [wall_best, badqacc_count]
#include <mujoco/mujoco.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static double now(void) {
  struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
  return ts.tv_sec + 1e-9 * ts.tv_nsec;
}

int main(int argc, char** argv) {
  if (argc < 8) { fprintf(stderr, "usage: see source\n"); return 1; }
  const char* xml = argv[1]; const char* drv = argv[2];
  const int mode = atoi(argv[3]); const long nstep = atol(argv[4]);
  const int nval = atoi(argv[5]); const long stride = atol(argv[6]); const char* out = argv[7];
  const int eq0 = argc > 8 ? atoi(argv[8]) : 0;
  const char* clk = argc > 9 ? argv[9] : "clock";
  const int repeats = argc > 10 ? atoi(argv[10]) : 2;

  char err[1000] = "";
  mjModel* m = mj_loadXML(xml, NULL, err, sizeof(err));
  if (!m) { fprintf(stderr, "load: %s\n", err); return 1; }
  mjData* d = mj_makeData(m);

  double* row = (double*)malloc(sizeof(double) * nstep * nval);
  FILE* f = fopen(drv, "rb");
  if (!f || fread(row, sizeof(double), nstep * nval, f) != (size_t)(nstep * nval)) { fprintf(stderr, "drive file\n"); return 1; }
  fclose(f);

  int cq = -1, cv = -1;
  if (mode == 2) {
    int jid = mj_name2id(m, mjOBJ_JOINT, clk);
    if (jid < 0) { fprintf(stderr, "no clock joint\n"); return 1; }
    cq = m->jnt_qposadr[jid]; cv = m->jnt_dofadr[jid];
  }
  const long nout = nstep / stride;
  double* rec = (double*)malloc(sizeof(double) * (nout + 1) * (1 + m->nq));
  double best = 1e300; int bad = 0;

  for (int rep = 0; rep < repeats; ++rep) {
    mj_resetData(m, d);
    if (mode == 2) d->qvel[cv] = 1.0;
    mj_forward(m, d);
    long w = 0;
    const double t0 = now();
    for (long k = 0; k < nstep; ++k) {
      const double* r = row + k * nval;
      if (mode == 0) {
        memcpy(d->ctrl, r, sizeof(double) * nval);
      } else if (mode == 1) {
        for (int i = 0; i < nval; ++i) m->eq_data[(eq0 + i) * mjNEQDATA] = r[i];
      } else {
        for (int i = 0; i < nval / 4; ++i)
          memcpy(m->eq_data + (eq0 + i) * mjNEQDATA, r + 4 * i, sizeof(double) * 4);
        d->qpos[cq] = 0.0; d->qvel[cv] = 1.0;   // virtual clock: tau = time since step start
      }
      mj_step(m, d);
      if ((k + 1) % stride == 0 && w < nout) {
        double* o = rec + w * (1 + m->nq); o[0] = d->time;
        memcpy(o + 1, d->qpos, sizeof(double) * m->nq); ++w;
      }
    }
    const double dt = now() - t0;
    if (dt < best) best = dt;
    bad = d->warning[mjWARN_BADQACC].number;
  }
  f = fopen(out, "wb");
  fwrite(rec, sizeof(double), nout * (1 + m->nq), f);
  double tail[2] = {best, (double)bad};
  fwrite(tail, sizeof(double), 2, f);
  fclose(f);
  printf("%ld %ld %.6f %d\n", nout, (long)m->nq, best, bad);
  mj_deleteData(d); mj_deleteModel(m); free(row); free(rec);
  return 0;
}
