#!/bin/bash
# Reproduce the report table. Run from the mujoco/ folder.
# RUNNER = built run_stewart (needs the ManifoldsX tree with setAccurateNewton). Without it,
# the saved ManifoldsX trajectory is scored instead.
set -e
RUNNER=${RUNNER:-../manifoldsx/run_stewart}
M=../model/stewart_spline1ms.json
TMP=${TMPDIR:-/tmp}
MJ=$(python3 -c "import mujoco, os; print(os.path.dirname(mujoco.__file__))")
[ -x mj_drive ] || gcc -O2 -o mj_drive mj_drive.c -I"$MJ/include" "$MJ"/libmujoco.so.* -Wl,-rpath,"$MJ"
HARD="0.9999 0.9999 0.001 0.5 2"

if [ -x "$RUNNER" ]; then
  echo "== ManifoldsX accurate (LTE 1e-5, steps <= 3 ms)"
  RS_OUTDT=1e-9 $RUNNER $M accurate 18 $TMP/stewart_bodies.json $TMP/mx_accurate_traj.csv | tail -1
  python3 ../manifoldsx/score_mx.py $TMP/mx_accurate_traj.csv
  python3 ../reference/fk_reference.py $TMP/mx_accurate_traj.csv
  echo "== ManifoldsX file settings, 1 ms"
  RS_DT=1e-3 $RUNNER $M file 18 | tail -1
else
  echo "== ManifoldsX: no RUNNER, scoring the saved accurate-mode trajectory"
  python3 ../reference/fk_reference.py ../results/mx_accurate_traj.csv
fi

echo "== MuJoCo, legs as constraints, stiffest settings (time constant = 2 x step, solimp 0.9999)"
for dt in 0.002 0.001 0.0005 0.00025; do
  MJS_SOLIMP="$HARD" python3 mj_stewart.py $dt implicitfast $(python3 -c "print(2*$dt)")
done
MJS_SOLIMP="$HARD" python3 mj_stewart.py 0.001 RK4 0.002
MJS_SOLIMP="$HARD" python3 mj_stewart.py 0.00025 RK4 0.0005
echo "== MuJoCo 1 ms: default constraint settings / target-only drive / servo legs (first version)"
python3 mj_stewart.py 0.001 implicitfast 0.02
MJS_DRIVE=eq MJS_SOLIMP="$HARD" python3 mj_stewart.py 0.001 implicitfast 0.002
MJS_DRIVE=servo python3 mj_stewart.py 0.001 implicitfast 0.02 1e8
