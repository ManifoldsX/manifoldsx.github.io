#!/bin/bash
# Check saved ManifoldsX results and rerun MuJoCo from mujoco/.
set -e
MJ=$(python3 -c "import mujoco, os; print(os.path.dirname(mujoco.__file__))")
[ -x mj_drive ] || gcc -O2 -o mj_drive mj_drive.c -I"$MJ/include" "$MJ"/libmujoco.so.* -Wl,-rpath,"$MJ"
HARD="0.9999 0.9999 0.001 0.5 2"

echo "== Checking saved ManifoldsX trajectory"
python3 ../reference/fk_reference.py ../results/mx_accurate_traj.csv

echo "== MuJoCo, legs as constraints, stiffest settings (time constant = 2 x step, solimp 0.9999)"
for dt in 0.002 0.001 0.0005 0.00025; do
  MJS_SOLIMP="$HARD" python3 mj_stewart.py $dt implicitfast $(python3 -c "print(2*$dt)")
done
MJS_SOLIMP="$HARD" python3 mj_stewart.py 0.001 RK4 0.002
MJS_SOLIMP="$HARD" python3 mj_stewart.py 0.00025 RK4 0.0005
echo "== MuJoCo 1 ms: default constraint settings / target-only drive / servo legs (first version)"
python3 mj_stewart.py 0.001 implicitfast 0.02
MJS_DRIVE=eq MJS_SOLIMP="$HARD" python3 mj_stewart.py 0.001 implicitfast 0.002
MJS_DRIVE=servo python3 mj_stewart.py 0.001 implicitfast 0.02 1e8
