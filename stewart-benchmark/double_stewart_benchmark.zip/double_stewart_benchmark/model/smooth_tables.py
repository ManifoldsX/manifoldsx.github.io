"""Spline-smooth the leg-length tables of a ManifoldsX JSON model.
Usage: python smooth_tables.py in.json out.json [spacing_s=0.001]
Linear tables have a velocity jump at every point, so a prescribed leg needs a
force spike that grows like 1/dt; a clamped cubic spline resampled finely removes it."""
import json, sys
import numpy as np
from scipy.interpolate import CubicSpline
src, dst = sys.argv[1], sys.argv[2]
h = float(sys.argv[3]) if len(sys.argv) > 3 else 0.001
d = json.load(open(src))
for m in d['motions']:
    law = m.get('scalar_law', {})
    if law.get('type') != 'table': continue
    tb = np.array(law['table']); t = np.round(np.arange(tb[0, 0], tb[-1, 0] + 1e-9, h), 9)
    y = CubicSpline(tb[:, 0], tb[:, 1], bc_type='clamped')(t)
    law['table'] = [[float(a), float(b)] for a, b in zip(t, y)]
    law['table_text'] = '; '.join('%.6f,%.10f' % (a, b) for a, b in zip(t, y))
json.dump(d, open(dst, 'w'))
print('smoothed', sum(1 for m in d['motions'] if m.get('scalar_law', {}).get('type') == 'table'), 'tables ->', dst)
