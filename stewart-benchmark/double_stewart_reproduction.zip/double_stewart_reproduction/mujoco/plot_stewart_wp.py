"""Speed vs platform error on the double Stewart: ManifoldsX and the MuJoCo twin.
Usage: python plot_stewart_wp.py sweep.jsonl out.png"""
import json, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sweep, out = sys.argv[1], sys.argv[2]
HARD = '0.9999'
rows = [json.loads(l) for l in open(sweep)]
rows = [r for r in rows if 'failed' not in r and r['stable'] and r['max_platform_pos_err_m'] is not None
        and r['max_platform_pos_err_m'] < 0.5]          # 0.5 m+ = diverged without a MuJoCo warning
def pick(**kw):
    sel = [r for r in rows if all((r['solimp'].split()[0] if k == 'si' else r[k]) == v for k, v in kw.items())]
    return sorted(((r['rtf'], r['max_platform_pos_err_m'], r['dt']) for r in sel))
series = [
    ('MuJoCo implicitfast — legs as constraints, stiffest settings', pick(integrator='implicitfast', drive='eqv', si=HARD), '#eb6834', '-', 'o'),
    ('MuJoCo RK4 — legs as constraints, stiffest settings', pick(integrator='RK4', drive='eqv', si=HARD), '#eb6834', '--', 's'),
    ('MuJoCo implicitfast — legs as constraints, default settings',
     pick(integrator='implicitfast', drive='eqv', si='0.9', eq_tc=0.02), '#b9b6ae', '-', 'o'),
    ('MuJoCo implicitfast — legs as servos (first version)', pick(integrator='implicitfast', drive='servo'), '#eb6834', ':', 'v'),
]
MX = [(13.8, 8.4e-10, 'ManifoldsX accurate\n(LTE 1e-5, steps ≤ 3 ms)'), (8.8, 1.2e-6, 'ManifoldsX file settings, 1 ms')]   # vs forward kinematics (reference/fk_reference.py)

SURF, INK, INK2, GRID, BLUE = '#fcfcfb', '#0b0b0b', '#52514e', '#e4e3df', '#2a78d6'
plt.rcParams.update({'font.size': 10, 'font.family': 'DejaVu Sans', 'axes.edgecolor': GRID,
                     'xtick.color': INK2, 'ytick.color': INK2, 'axes.labelcolor': INK2})
fig, ax = plt.subplots(figsize=(9, 6.2), facecolor=SURF); ax.set_facecolor(SURF)
for lab, pts, c, ls, mk in series:
    if not pts: continue
    x = [p[0] for p in pts]; y = [p[1] for p in pts]
    ax.plot(x, y, ls=ls, color=c, lw=1.8, marker=mk, ms=7, mfc=c if ls == '-' else SURF, mec=c, mew=1.6, label=lab, zorder=3)
    for w, e, dt in pts:
        if c == '#b9b6ae' and dt < 1e-3: continue      # crowded; 1 and 2 ms are enough
        ax.annotate(f'{dt*1e3:g} ms', (w, e), xytext=(6, 4), textcoords='offset points', fontsize=8, color=INK2)
for i, (w, e, lab) in enumerate(MX):
    ax.plot([w], [e], marker='D' if i == 0 else 'o', ms=9, color=BLUE, mfc=BLUE if i == 0 else SURF, mew=1.8, ls='none',
            label=lab.replace('\n', ' '), zorder=4)
    ax.annotate(lab, (w, e), xytext=(9, -4 if i == 0 else 4), textcoords='offset points', fontsize=8.5, color=BLUE, va='center')
ax.axvline(1.0, color=INK2, lw=0.8, ls=':', zorder=1)
ax.text(1.04, 1e-6, 'real\ntime', fontsize=8.5, color=INK2)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_ylim(3e-10, 2e-1); ax.set_xlim(0.8, 45)
ax.set_xticks([1, 2, 5, 10, 20, 40]); ax.set_xticklabels(['1', '2', '5', '10', '20', '40'])
ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
ax.set_xlabel('speed (× real time, one core)  —  right is faster')
ax.set_ylabel('max top-platform position error over 18 s (m)  —  lower is more accurate')
ax.grid(True, which='major', color=GRID, lw=0.8); ax.set_axisbelow(True)
for sp in ('top', 'right'): ax.spines[sp].set_visible(False)
ax.tick_params(length=0)
ax.legend(frameon=False, fontsize=8.5, loc='upper left')
fig.text(0.125, 0.955, 'Double Stewart platform: speed vs accuracy', fontsize=13, weight='bold', color=INK)
fig.text(0.125, 0.925, 'Error against the exact kinematic solution (forward kinematics from the leg lengths). MuJoCo stiffest settings: constraint time constant = 2 × step, '
         'solimp 0.9999,\nleg drive as a velocity-consistent joint equality. MuJoCo default settings: time constant 20 ms, solimp 0.9/0.95.',
         fontsize=8.6, color=INK2, va='top')
fig.subplots_adjust(top=0.86)
fig.savefig(out, dpi=130, facecolor=SURF, bbox_inches='tight')
for lab, pts, *_ in series: print(lab, [(w, '%.1e' % e, dt) for w, e, dt in pts])
