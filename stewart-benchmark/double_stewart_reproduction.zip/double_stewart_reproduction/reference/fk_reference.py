"""Independent reference for the double Stewart benchmark: forward kinematics from the leg lengths.

With every joint satisfied, each platform's pose is a pure function of its six leg lengths, so the
exact answer needs no dynamics at all. This script solves the two forward-kinematics problems
(stage 1: base -> middle platform, stage 2: middle -> top platform) with Newton's method at the
times of a trajectory file, and reports the platform position error of that trajectory against it.

Leg length = distance between a leg's base and top spherical-joint points. The legs are straight
(the base point, slider markers and top point are collinear; checked at t = 0), so
    length_i(t) = c_i + s_i(t)
where s_i(t) is the leg's prismatic table, interpolated linearly as ManifoldsX does, and c_i is
fixed by the initial pose.

Usage: python fk_reference.py traj.csv [traj.csv ...]
  traj.csv: columns t, p2_x..p2_qz, p3_x..p3_qz (run_stewart output). Prints, per file, the max
  position error of platforms 2 and 3 and the residual of the solved leg lengths.
Env: FK_MODEL (default ../model/stewart_spline1ms.json), FK_BODIES (default ../mujoco/bodies.json),
     FK_STRIDE (use every n-th row, default 1), FK_OUT (write the FK platform positions to this CSV).
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.environ.get("FK_MODEL", os.path.join(HERE, "..", "model", "stewart_spline1ms.json"))
BODIES = os.environ.get("FK_BODIES", os.path.join(HERE, "..", "mujoco", "bodies.json"))
STRIDE = int(os.environ.get("FK_STRIDE", "1"))


def quat_to_R(q):
    w, x, y, z = np.asarray(q, float) / np.linalg.norm(q)
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def skew(v):
    return np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])


def expm_so3(w):
    th = np.linalg.norm(w)
    if th < 1e-14:
        return np.eye(3) + skew(w)
    K = skew(w / th)
    return np.eye(3) + np.sin(th) * K + (1 - np.cos(th)) * K @ K


doc = json.load(open(MODEL))
bod = {p["id"]: p for p in json.load(open(BODIES))["parts"]}
markers = {m["id"]: m for m in doc["markers"]}
joints = sorted(doc["joints"], key=lambda j: j["id"])
tables = {(m["marker_a"], m["marker_b"]): np.array(m["scalar_law"]["table"]) for m in doc["motions"]}


def local(mid):
    return np.array(markers[mid]["part_T_marker"]["r"], float), markers[mid]["part_id"]


def world0(mid):
    r_loc, pid = local(mid)
    b = bod[pid]
    return np.array(b["r"]) + quat_to_R(b["q"]) @ r_loc


# Legs: (base spherical, slider, top spherical) triplets, as in the MuJoCo twin.
legs = []
for i in range(0, len(joints), 3):
    base, slide, top = joints[i], joints[i + 1], joints[i + 2]
    assert base["kind"] == "Spherical" and slide["kind"] == "Prismatic" and top["kind"] == "Spherical"
    pb, base_part = local(base["marker_a"])
    pt, top_part = local(top["marker_b"])
    tab = tables[(slide["marker_a"], slide["marker_b"])]
    # Straightness check at t = 0: base point, slider markers and top point on one line.
    pts = [world0(base["marker_a"]), world0(slide["marker_a"]), world0(slide["marker_b"]), world0(top["marker_b"])]
    axis = (pts[3] - pts[0]) / np.linalg.norm(pts[3] - pts[0])
    off_line = max(np.linalg.norm((p - pts[0]) - axis * np.dot(p - pts[0], axis)) for p in pts)
    L0 = np.linalg.norm(pts[3] - pts[0])
    legs.append(dict(base_part=base_part, top_part=top_part, pb=pb, pt=pt, t=tab[:, 0], s=tab[:, 1],
                     c=L0 - tab[0, 1], off_line=off_line))

stage = {}
for L in legs:
    stage.setdefault((L["base_part"], L["top_part"]), []).append(L)
assert len(stage) == 2 and all(len(v) == 6 for v in stage.values())
(base1, plat1), (base2, plat2) = sorted(stage.keys(), key=lambda k: k[1])
assert bod[base1].get("fixed") == 1, "stage 1 must stand on the fixed base"
print(f"legs straight at t=0: max off-line distance {max(L['off_line'] for L in legs):.1e} m")


def solve_stage(legs6, base_r, base_R, r, R, t):
    """Newton on |r + R pt - (base_r + base_R pb)| = length(t) for six legs; returns r, R, residual."""
    lens = np.array([L["c"] + np.interp(t, L["t"], L["s"]) for L in legs6])
    B = np.array([base_r + base_R @ L["pb"] for L in legs6])
    P = np.array([L["pt"] for L in legs6])
    for _ in range(30):
        tops = r + P @ R.T
        d = tops - B
        dist = np.linalg.norm(d, axis=1)
        f = dist - lens
        if np.max(np.abs(f)) < 1e-14:
            break
        u = d / dist[:, None]
        # d(dist)/d(dr) = u ; d(dist)/d(w) = (R pt) x u  (rotation increment w applied on the left)
        Jr = u
        Jw = np.cross(P @ R.T, u)
        J = np.hstack([Jr, Jw])
        dx = np.linalg.solve(J, -f)
        r = r + dx[:3]
        R = expm_so3(dx[3:]) @ R
    tops = r + P @ R.T
    res = np.max(np.abs(np.linalg.norm(tops - B, axis=1) - lens))
    return r, R, res


def rot_angle(Ra, Rb):
    """Angle of the rotation between two orientations, accurate for tiny angles."""
    A = Ra.T @ Rb
    v = 0.5 * np.array([A[2, 1] - A[1, 2], A[0, 2] - A[2, 0], A[1, 0] - A[0, 1]])
    c = 0.5 * (np.trace(A) - 1.0)
    return float(np.arctan2(np.linalg.norm(v), c))


def run(path):
    data = np.genfromtxt(path, delimiter=",", names=True)[::STRIDE]
    r1, R1 = np.array(bod[plat1]["r"]), quat_to_R(bod[plat1]["q"])
    r2, R2 = np.array(bod[plat2]["r"]), quat_to_R(bod[plat2]["q"])
    base_r, base_R = np.array(bod[base1]["r"]), quat_to_R(bod[base1]["q"])
    err1 = err2 = res_max = 0.0
    ang1 = ang2 = 0.0
    out = []
    for row in data:
        t = row["t"]
        r1, R1, res1 = solve_stage(stage[(base1, plat1)], base_r, base_R, r1, R1, t)
        r2, R2, res2 = solve_stage(stage[(base2, plat2)], r1, R1, r2, R2, t)
        res_max = max(res_max, res1, res2)
        e1 = np.linalg.norm(np.array([row[f"p{plat1}_{c}"] for c in "xyz"]) - r1)
        e2 = np.linalg.norm(np.array([row[f"p{plat2}_{c}"] for c in "xyz"]) - r2)
        err1, err2 = max(err1, e1), max(err2, e2)
        a1 = rot_angle(quat_to_R([row[f"p{plat1}_{c}"] for c in ("qw", "qx", "qy", "qz")]), R1)
        a2 = rot_angle(quat_to_R([row[f"p{plat2}_{c}"] for c in ("qw", "qx", "qy", "qz")]), R2)
        ang1, ang2 = max(ang1, a1), max(ang2, a2)
        out.append((t, *r1, *r2))
    print(f"{os.path.basename(path)}: {len(data)} samples, max position error vs forward kinematics: "
          f"platform {plat1} {err1:.2e} m, platform {plat2} {err2:.2e} m; "
          f"max orientation error: platform {plat1} {ang1:.2e} rad, platform {plat2} {ang2:.2e} rad "
          f"(FK leg-length residual {res_max:.1e} m)")
    if os.environ.get("FK_OUT"):
        np.savetxt(os.environ["FK_OUT"], np.array(out), delimiter=",", fmt="%.12f",
                   header=f"t,p{plat1}_x,p{plat1}_y,p{plat1}_z,p{plat2}_x,p{plat2}_y,p{plat2}_z", comments="")


for p in sys.argv[1:]:
    run(p)
