# Two-stage Stewart platform: reproduction package

Two Stewart platforms are stacked and driven by their 12 leg lengths for 18 s. With every joint closed, the pose of each platform is pure geometry, so the exact answer is forward kinematics from the leg lengths. Nothing about the dynamics has to be trusted to know it.

The published result: over the full run, ManifoldsX keeps both platforms within 10⁻⁹ m in position (8.5×10⁻¹⁰ m) and 2×10⁻⁹ rad in orientation of forward kinematics, with every loop closed to 10⁻¹¹ m, at about 12× real time on one core of a 2.1 GHz Intel Xeon. Settings: HHT index-3 with local error control at 10⁻⁵ and steps up to 3 ms. The model file's own settings (fixed 1 ms steps) give the same errors at about 8× real time. The report is at https://manifoldsx.github.io/stewart-benchmark/.

This package lets you check that number without the solver. It holds the model, the saved ManifoldsX trajectories, the independent forward-kinematics reference, and a MuJoCo twin you can run yourself. The ManifoldsX solver is not included.

## Check the ManifoldsX result (about 5 s, needs Python and NumPy)

```
python reference/fk_reference.py results/mx_accurate_traj.csv
```

It solves the forward kinematics of both stages from the leg lengths at every saved time and prints the largest platform position and orientation errors. Expected: 8.5×10⁻¹⁰ m and 1.8×10⁻⁹ rad (middle), 8.4×10⁻¹⁰ m and 1.9×10⁻⁹ rad (top).

## Run the MuJoCo twin (needs `pip install mujoco scipy` and a C compiler)

```
cd mujoco
../run_all.sh
```

## Contents

- `model/`
  - `stewart_two_stage_20ms_tables.json`: the original ManifoldsX model, with leg-length tables at 20 ms.
  - `stewart_spline1ms.json`: the same model with leg tables spline-smoothed to 1 ms. Both solvers use this one.
  - `smooth_tables.py`: regenerates the smoothed model (`python smooth_tables.py in.json out.json 0.001`).
- `reference/fk_reference.py traj.csv [...]`: the independent reference. Works on trajectory files from either solver.
- `manifoldsx/score_mx.py traj.csv`: largest platform error of a ManifoldsX run against the 0.25 ms run.
- `results/`
  - `mx_accurate_traj.csv`: the published run (error-controlled, steps up to 3 ms), every step.
  - `mx_file1ms_traj.csv`: the model file's own settings (fixed 1 ms), every step.
  - `mx_tight_reference_traj.csv`: ManifoldsX at a fixed 0.25 ms step, every step.
  - `summary.csv`: every row of the report table, both solvers.
  - `fk_check.txt`: the forward-kinematics check and speed runs behind the report, with the machine they ran on.
  - `mujoco_sweep.jsonl`, `mujoco_clockfix_rerun.jsonl`: the MuJoCo sweep and the re-run of its constraint-driven rows.
- `mujoco/`
  - `mj_stewart.py`: the MuJoCo 3.15 twin, built from the ManifoldsX JSON and `bodies.json`. Usage: `python mj_stewart.py <dt> <implicitfast|RK4> [equality_timeconst=0.02] [kp=1e8] [T=18]`. Prints speed, loop gap, leg error and platform error as JSON. Environment variables: `MJS_DRIVE` = `eqv` (default), `eq` or `servo` for the leg drive; `MJS_DRIVE_TC` for the leg-constraint time constant; `MJS_SOLIMP` for the solimp of all equality constraints.
  - `mj_drive.c`: a plain C loop around `mj_step` that refreshes the leg targets every step. `run_all.sh` builds it.
  - `sweep.sh`: the full sweep (integrators × steps × constraint settings, plus the servo version).
  - `plot_stewart_wp.py sweep.jsonl out.png`: the speed-versus-accuracy chart.
  - `bodies.json`: body masses, inertias and poses, dumped from ManifoldsX at full precision.

## How the MuJoCo twin is built

- **Joints.** The leg-base spherical joints become ball joints and the leg sliders become slide joints, which makes a tree.
- **Loops.** Each top spherical joint is an equality `connect`, MuJoCo's standard way to close a kinematic loop.
- **Leg drive.** MuJoCo has no time-driven joint constraint, so there are three options.
  - `eqv`: a joint equality per leg, coupled to a virtual clock slider (a separate 10⁶ kg body reset each step to τ = 0, moving at 1 m/s). The equality's polynomial is the cubic Taylor expansion of the leg table around the current time, refreshed every step, so the constraint sees the target's position and velocity.
  - `eq`: a joint equality with only its target position refreshed every step, the usual recipe. MuJoCo's stabilization damps the leg velocity towards zero, so the leg lags the target.
  - `servo`: a position actuator per leg, with kv near critical.
- **Accuracy.** With all constraints satisfied the platform pose is a pure function of the leg lengths, so the platform error measures constraint error in both solvers. `mj_stewart.py` also prints an error against the ManifoldsX 0.25 ms run, which agrees with forward kinematics to three digits for every MuJoCo row.
